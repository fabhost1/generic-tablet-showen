from django.db import models

# Create your models here.
class aspirin(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'aspirin'
class Bcomplex(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'Bcomplex'
class Calamine(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'calamine'
class BACAMPICILLIN(models.Model): 
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'BACAMPICILLIN'
class meddetail(models.Model): 
    generic=models.TextField(max_length=20)
    uses=models.TextField(max_length=1000)
    sideeffects=models.TextField(max_length=1000)
class meddetails(models.Model): 
    generic=models.TextField(max_length=20)
    uses=models.TextField(max_length=1000)
    sideeffects=models.TextField(max_length=1000)
    international=models.TextField(max_length=1000,blank=True)
    class Meta:
        db_table = 'meddetails'
class A(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'A'
class B(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'B'
class C(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'C'
class D(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'D'
class E(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'E'
class F(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'F'
class G(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'G'
class H(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'H'
class I(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'I'
class J(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'J'
class K(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'K'
class L(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'L'
class M(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'M'
class N(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'N'
class O(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'O'
class P(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'P'
class Q(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'Q'
class R(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'R'
class S(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'S'
class T(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'T'
class U(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'U'
class W(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'W'
class X(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'X'
class Y(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'Y'
class Z(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'Z'
class V(models.Model):
    generic=models.TextField(max_length=20)
    brand=models.TextField(max_length=20)
    class Meta:
        db_table = 'V'