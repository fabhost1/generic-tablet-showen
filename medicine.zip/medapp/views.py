from django.shortcuts import render
import cv2
from .models import aspirin,meddetails,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z
######################################
import pytesseract
from PIL import Image
import io
#####################################
#Create your views here.
def just(request):
    data=Z()
    data.generic=request.POST.get('generic')
    data.brand=request.POST.get('brand')
    data.save()
    return render (request,'index.html')
def home(request):
    return render(request,'index.html')
def search(request):
    catch=request.POST.get('search')
    aspirin.brand
    show=aspirin.objects.filter(generic=catch)
    return render(request,'base.html',{'show':show,'catch':catch})
def data(request):
    
    value=request.POST.get('gen')
    show=meddetails.objects.filter(generic=value)
    return render(request,'result.html',{'show':show})

def camera1(request):
    vid = cv2.VideoCapture(0)
    while(True):
        ret, frame = vid.read()
        cv2.imshow('frame', frame)
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    cv2.imwrite(r"C:\Users\FABHOSTPYTHON\Desktop\medicine\medapp\images\out1.jpg" , frame)
    vid.release()
    cv2.destroyAllWindows()
    pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract'
    image_data =cv2.imread(r"C:\Users\FABHOSTPYTHON\Desktop\medicine\medapp\images\out1.jpg")
    
    
    catch=pytesseract.image_to_string(image_data).strip()
    #print(catch)
    #show=aspirin.objects.filter(generic=catch)
    #print("hello",show)
    #return render(request,'base.html',{'show':show})
    print(catch)
  
    
    return render(request,'index1.html',{'catch':catch})
def tesout(request):
    out=request.POST.get('search1')
    print(out,'catch')
    show=aspirin.objects.filter(generic=out)
    print("hello",show)
    return render(request,'base.html',{'show':show})
def a(request):
    show=A.objects.all()
    return render(request,'alphpet.html',{'show':show})
def b(request):
    show=B.objects.all()
    return render(request,'alphpet.html',{'show':show})
def c(request):
    show=C.objects.all()
    return render(request,'alphpet.html',{'show':show})
def d(request):
    show=D.objects.all()
    return render(request,'alphpet.html',{'show':show})
def e(request):
    show=E.objects.all()
    return render(request,'alphpet.html',{'show':show})
def f(request):
    show=F.objects.all()
    return render(request,'alphpet.html',{'show':show})
def g(request):
    show=G.objects.all()
    return render(request,'alphpet.html',{'show':show})
def h(request):
    show=H.objects.all()
    return render(request,'alphpet.html',{'show':show})
def i(request):
    show=I.objects.all()
    return render(request,'alphpet.html',{'show':show})
def j(request):
    show=J.objects.all()
    return render(request,'alphpet.html',{'show':show})
def k(request):
    show=K.objects.all()
    return render(request,'alphpet.html',{'show':show})
def l(request):
    show=L.objects.all()
    return render(request,'alphpet.html',{'show':show})
def m(request):
    show=M.objects.all()
    return render(request,'alphpet.html',{'show':show})
def n(request):
    show=N.objects.all()
    return render(request,'alphpet.html',{'show':show})
def o(request):
    show=O.objects.all()
    return render(request,'alphpet.html',{'show':show})
def p(request):
    show=P.objects.all()
    return render(request,'alphpet.html',{'show':show})
def q(request):
    show=Q.objects.all()
    return render(request,'alphpet.html',{'show':show})
def r(request):
    show=R.objects.all()
    return render(request,'alphpet.html',{'show':show})
def s(request):
    show=S.objects.all()
    return render(request,'alphpet.html',{'show':show})
def t(request):
    show=T.objects.all()
    return render(request,'alphpet.html',{'show':show})
def u(request):
    show=U.objects.all()
    return render(request,'alphpet.html',{'show':show})
def v(request):
    show=V.objects.all()
    return render(request,'alphpet.html',{'show':show})
def w(request):
    show=W.objects.all()
    return render(request,'alphpet.html',{'show':show})
def x(request):
    show=X.objects.all()
    return render(request,'alphpet.html',{'show':show})
def y(request):
    show=Y.objects.all()
    return render(request,'alphpet.html',{'show':show})
def z(request):
    show=Z.objects.all()
    return render(request,'alphpet.html',{'show':show})
def data1(request,brand):
    show= meddetails.objects.filter(generic=brand)
    return render(request,'result.html',{'show':show})

