"""medicine URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from medapp.models import V
from medapp.views import home,search,data,camera1,tesout,a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,just,data1
urlpatterns = [
    path('just',just),
    path('data1<str:brand>',data1),
    path('',home),
    path('camera/',camera1),
    path('camera/search',tesout),
    path('camera/data',data),
    path('data',data),
    path('search',search),
    path('admin/', admin.site.urls),
    path('a',a),
    path('b',b),
    path('c',c),
    path('d',d),
    path('e',e),
    path('f',f),
    path('g',g),
    path('h',h),
    path('i',i),
    path('j',j),
    path('k',k),
    path('l',l),
    path('m',m),
    path('n',n),
    path('o',o),
    path('p',p),
    path('q',q),
    path('r',r),
    path('s',s),
    path('t',t),
    path('u',u),
    path('v',v),
    path('w',w),
    path('x',x),
    path('y',y),
    path('z',z),

]
